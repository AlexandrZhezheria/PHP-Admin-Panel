
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` tinyint unsigned NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `languages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'EN','en',1,0,NULL,NULL),(2,'FR','fr',1,0,'2022-12-24 07:18:04','2022-12-24 07:18:04');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta` json DEFAULT NULL,
  `main` json DEFAULT NULL,
  `sort` tinyint unsigned NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  `category_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`),
  KEY `pages_category_id_foreign` (`category_id`),
  CONSTRAINT `pages_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Index','/','{\"1\": {\"title\": null, \"keywords\": null, \"description\": null}, \"2\": {\"title\": null, \"keywords\": null, \"description\": null}}',NULL,1,0,1,NULL,'2023-01-14 07:58:09'),(2,'About','/about','{\"1\": {\"title\": null, \"keywords\": null, \"description\": null}, \"2\": {\"title\": null, \"keywords\": null, \"description\": null}}',NULL,1,0,1,'2022-12-24 07:11:57','2023-01-12 16:19:32'),(3,'Home','/home-page','{\"1\": {\"title\": null, \"keywords\": null, \"description\": null}, \"2\": {\"title\": null, \"keywords\": null, \"description\": null}}',NULL,1,0,1,'2023-01-12 15:22:45','2023-01-12 16:28:05'),(9,'New','/new','{\"1\": {\"title\": null, \"keywords\": null, \"description\": null}, \"2\": {\"title\": null, \"keywords\": null, \"description\": null}}',NULL,1,0,1,'2023-01-12 15:32:24','2023-01-12 15:43:13'),(10,'From','/from',NULL,NULL,1,0,1,'2023-01-12 16:10:15','2023-01-12 16:10:15'),(13,'Wdrevgfds','/wdrevgfds',NULL,NULL,1,0,1,'2023-01-12 16:55:47','2023-01-12 16:55:47');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` json DEFAULT NULL,
  `sort` tinyint unsigned NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Page','page','{\"1\": {\"title\": \"Page\"}}',1,0,NULL,NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'header',
  `options` json DEFAULT NULL,
  `sort` tinyint unsigned NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  `template_id` bigint unsigned NOT NULL,
  `menu_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menus_template_id_foreign` (`template_id`),
  KEY `menus_menu_id_foreign` (`menu_id`),
  CONSTRAINT `menus_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menus_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Menu 1','header','{\"1\": {\"title\": \"Головна\"}, \"2\": {\"title\": null}}',1,1,33,NULL,'2023-01-10 14:50:09','2023-01-10 16:48:38'),(2,'Menu 2','footer','{\"1\": {\"title\": null}, \"2\": {\"title\": null}}',0,1,33,NULL,'2023-01-10 14:55:37','2023-01-10 16:48:49'),(4,'Menu 1',NULL,'{\"1\": {\"view\": \"fdsafgdaf\", \"title\": \"aesfds\"}, \"2\": {\"view\": null, \"title\": null}}',1,0,35,1,NULL,'2023-01-10 16:08:19'),(5,'Menu 1','header','{\"1\": {\"view\": \"fadsfgads\", \"title\": \"adsfads\"}, \"2\": {\"view\": null, \"title\": null}}',1,0,35,1,NULL,'2023-01-10 16:08:19'),(6,'Menu 1',NULL,'{\"1\": {\"view\": null, \"title\": null}, \"2\": {\"view\": null, \"title\": null}}',1,0,35,1,NULL,'2023-01-10 16:08:19'),(7,'Menu 1',NULL,'{\"1\": {\"view\": null, \"title\": null}, \"2\": {\"view\": null, \"title\": null}}',1,0,35,1,NULL,'2023-01-10 16:08:19'),(13,'Menu 2','footer','{\"1\": {\"view\": null, \"title\": null}, \"2\": {\"view\": null, \"title\": null}}',1,0,35,2,NULL,'2023-01-10 16:41:18'),(15,'Name','header','{\"1\": {\"name\": \"mokmpokm\"}, \"2\": {\"name\": \"pojkpokjp\"}}',0,1,36,NULL,'2023-01-10 15:53:37','2023-01-10 16:48:35'),(16,NULL,NULL,NULL,1,0,33,NULL,'2023-01-10 16:31:38','2023-01-10 16:31:38');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fields` json DEFAULT NULL,
  `sort` tinyint unsigned NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  `template_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `templates_slug_unique` (`slug`),
  KEY `templates_template_id_foreign` (`template_id`),
  CONSTRAINT `templates_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES (6,'Secont Block','secont-block','page','http://admin-panel/storage/templates/secont-block.jpg','[]',0,0,NULL,'2022-12-22 16:40:11','2023-01-10 16:27:26'),(7,NULL,NULL,NULL,NULL,NULL,1,0,6,'2022-12-22 16:40:15','2022-12-22 16:40:15'),(9,NULL,NULL,NULL,NULL,NULL,1,0,7,'2022-12-22 16:41:48','2022-12-22 16:41:48'),(10,'Third Block','third-block','page','http://admin-panel/storage/templates/third-block.jpg','[]',2,0,NULL,'2022-12-22 16:49:08','2023-01-10 16:27:26'),(11,NULL,NULL,NULL,NULL,NULL,1,0,10,'2022-12-22 16:49:10','2022-12-22 16:49:10'),(12,'Fourth','fourth','page','http://admin-panel/storage/templates/fourth.jpg','[{\"name\": \"title\", \"type\": \"input\", \"label\": \"Title FL\"}, {\"name\": \"img\", \"type\": \"image\", \"label\": \"Img\"}, {\"name\": \"dsfds\", \"type\": \"date\", \"label\": \"ewrf\"}, {\"name\": \"fdagdasf\", \"type\": \"color\", \"label\": \"dsfsd\"}]',3,0,NULL,'2022-12-22 16:53:24','2023-01-10 16:27:26'),(16,'Rthegfh','rthegfh','page','http://admin-panel/storage/templates/rthegfh.jpg','[]',4,0,NULL,'2022-12-22 16:58:05','2023-01-10 16:27:26'),(17,NULL,NULL,NULL,NULL,NULL,1,0,16,'2022-12-22 16:58:10','2022-12-22 16:58:10'),(18,NULL,NULL,NULL,NULL,NULL,1,0,17,'2022-12-22 16:58:12','2022-12-22 16:58:12'),(19,NULL,NULL,NULL,NULL,NULL,1,0,18,'2022-12-22 16:58:18','2022-12-22 16:58:18'),(20,NULL,NULL,NULL,NULL,NULL,1,0,19,'2022-12-22 16:58:37','2022-12-22 16:58:37'),(21,NULL,NULL,NULL,NULL,NULL,1,0,20,'2022-12-22 16:58:40','2022-12-22 16:58:40'),(22,'Aesdfdas','aesdfdas','page','http://admin-panel/storage/templates/aesdfdas.png','[{\"name\": \"qwreqw\", \"type\": \"input\", \"label\": \"qwerqwr\"}, {\"name\": \"image\", \"type\": \"image\", \"label\": \"Image\"}]',6,1,NULL,'2022-12-24 06:02:04','2023-01-14 07:57:57'),(27,NULL,NULL,NULL,NULL,NULL,1,0,11,'2022-12-24 06:27:38','2022-12-24 06:27:38'),(28,NULL,NULL,NULL,NULL,NULL,1,0,27,'2022-12-24 06:27:41','2022-12-24 06:27:41'),(29,NULL,NULL,NULL,NULL,'[{\"name\": \"rqwrqwe\", \"type\": \"input\", \"label\": \"qwreqw\"}, {\"name\": \"weqwrqw\", \"type\": \"image\", \"label\": \"qwreqwe\"}]',1,0,12,'2022-12-24 06:34:56','2022-12-24 06:52:18'),(30,'Template','template','page','http://admin-panel/storage/templates/template.png','[]',5,0,NULL,'2022-12-24 07:10:52','2023-01-10 16:27:26'),(31,'Two Level Template','two-level-template','page','http://admin-panel/storage/templates/two-level-template.jpg','[{\"name\": \"title\", \"type\": \"input\", \"label\": \"Title\"}, {\"name\": \"description\", \"type\": \"textarea\", \"label\": \"Description\"}]',1,1,NULL,'2022-12-24 07:11:30','2023-01-10 16:27:26'),(32,NULL,NULL,NULL,NULL,'[{\"name\": \"title\", \"type\": \"input\", \"label\": \"Title\"}, {\"name\": \"description\", \"type\": \"textarea\", \"label\": \"Description\"}, {\"name\": \"price\", \"type\": \"input\", \"label\": \"Price\"}]',1,0,31,'2022-12-24 07:12:13','2022-12-24 07:15:58'),(33,'Template Menu','template-menu','menu','http://admin-panel/storage/templates/template-menu.png','[{\"name\": \"title\", \"type\": \"input\", \"label\": \"Title\"}]',0,1,NULL,'2023-01-10 14:49:33','2023-01-10 16:27:30'),(35,NULL,NULL,NULL,NULL,'[{\"name\": \"title\", \"type\": \"input\", \"label\": \"Title\"}, {\"name\": \"view\", \"type\": \"input\", \"label\": \"View\"}]',1,0,33,'2023-01-10 15:04:06','2023-01-10 15:31:21'),(36,'Menu 1 Level','menu-1-level','menu','http://admin-panel/storage/templates/menu-1-level.png','[{\"name\": \"name\", \"type\": \"input\", \"label\": \"Name\"}]',1,1,NULL,'2023-01-10 15:53:20','2023-01-10 16:27:30');
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` json DEFAULT NULL,
  `sort` tinyint unsigned NOT NULL DEFAULT '1',
  `show` tinyint(1) NOT NULL DEFAULT '0',
  `page_id` bigint unsigned DEFAULT NULL,
  `template_id` bigint unsigned NOT NULL,
  `block_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blocks_page_id_foreign` (`page_id`),
  KEY `blocks_template_id_foreign` (`template_id`),
  KEY `blocks_block_id_foreign` (`block_id`),
  CONSTRAINT `blocks_block_id_foreign` FOREIGN KEY (`block_id`) REFERENCES `blocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blocks_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blocks_template_id_foreign` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` VALUES (1,NULL,'{\"1\": {\"image\": \"http://admin-panel/storage/blocks/1/1/image/21034716451662397565.png\", \"qwreqw\": null}, \"2\": {\"image\": null, \"qwreqw\": null}}',1,0,1,22,NULL,'2022-12-24 06:02:18','2023-01-14 07:58:09'),(2,NULL,'{\"1\": {\"title\": \"our price plans\", \"description\": \"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.\"}, \"2\": {\"title\": null, \"description\": null}}',2,0,2,31,NULL,'2022-12-24 07:16:07','2023-01-12 16:19:32'),(3,NULL,'{\"1\": {\"qwreqw\": null}, \"2\": {\"qwreqw\": null}}',1,0,2,22,NULL,'2022-12-24 07:24:09','2023-01-12 16:19:32'),(4,NULL,'{\"1\": {\"price\": \"49\", \"title\": \"Basic\", \"description\": \"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet, nemo.\"}, \"2\": {\"price\": null, \"title\": null, \"description\": null}}',5,0,NULL,32,2,NULL,'2023-01-12 16:19:32'),(5,NULL,'{\"1\": {\"price\": null, \"title\": \"Second\", \"description\": null}, \"2\": {\"price\": null, \"title\": null, \"description\": null}}',3,0,NULL,32,2,NULL,'2023-01-12 16:19:32'),(8,NULL,'{\"1\": {\"price\": null, \"title\": null, \"description\": null}, \"2\": {\"price\": null, \"title\": null, \"description\": null}}',4,0,NULL,32,2,NULL,'2023-01-12 16:19:32'),(9,NULL,'{\"1\": {\"price\": null, \"title\": null, \"description\": null}, \"2\": {\"price\": null, \"title\": null, \"description\": null}}',6,0,NULL,32,2,NULL,'2023-01-12 16:19:32'),(10,NULL,'{\"1\": {\"price\": null, \"title\": null, \"description\": null}, \"2\": {\"price\": null, \"title\": null, \"description\": null}}',7,0,NULL,32,2,NULL,'2023-01-12 16:19:32'),(12,NULL,NULL,1,0,NULL,35,1,NULL,NULL),(13,NULL,NULL,1,0,NULL,35,1,NULL,NULL),(14,NULL,'{\"1\": {\"title\": null, \"description\": null}, \"2\": {\"title\": null, \"description\": null}}',0,0,2,31,NULL,'2023-01-10 16:57:10','2023-01-12 16:19:32'),(15,NULL,'{\"1\": {\"title\": null, \"description\": null}, \"2\": {\"title\": null, \"description\": null}}',8,0,2,31,NULL,'2023-01-10 16:57:24','2023-01-12 16:19:32'),(16,NULL,'{\"1\": {\"title\": null, \"description\": null}, \"2\": {\"title\": null, \"description\": null}}',1,0,1,31,NULL,'2023-01-12 15:05:32','2023-01-14 07:58:09');
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

